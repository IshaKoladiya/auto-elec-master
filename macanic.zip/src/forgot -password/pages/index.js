import { lazy } from "react";

const ForgotPassword = lazy(()=>import("../components/ForgotPassword"))

export {ForgotPassword}