import { lazy } from "react";

const NewPassword = lazy(()=>import("../components/NewPassword"))

export {NewPassword}