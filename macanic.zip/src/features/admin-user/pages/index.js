import { lazy } from "react";

const AdminUsers = lazy(()=>import('../components/AdminUsers.jsx'))
export {AdminUsers}