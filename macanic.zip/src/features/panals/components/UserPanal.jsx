import React from 'react'

const UserPanal = () => {
  return (
    <div>
      <h1>User Panel</h1>
    </div>
  )
}

export default UserPanal
