import React from 'react'

const TechnicianPanal = () => {
  return (
    <div>
      <h1>Technician</h1>
    </div>
  )
}

export default TechnicianPanal
