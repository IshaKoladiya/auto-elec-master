import { createContext } from 'react'
const MainAuthContext = createContext();
export default MainAuthContext;
 
